#!/usr/bin/env bash
echo 'Elyon-Sol Demo CLI (public-safe)'