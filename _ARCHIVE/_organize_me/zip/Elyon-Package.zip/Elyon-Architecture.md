
# Elyon‑Sol Architecture Diagram

```
Core Engine
 ├─ Reasoning
 ├─ Memory Manager
 ├─ Governance (Triad + OSPF)
 └─ Co‑Author Interface

Layers:
 • Private context  
 • Public context  
 • Temporal context  
Modes: Public, Dev, Private, Temporal
```
